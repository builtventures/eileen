var bedhad = {
  product_slider: function(){
     $('.thumb_slider_show').flickity({
          // options
          wrapAround: false,
          pageDots: false       
    }); 
    $('.product-gallery__thumbnails').flickity({
      asNavFor: '.thumb_slider_show',
      contain: true, 
      wrapAround: false,
      pageDots: false
    });
  },
  slider_funciton: function(){ 
    

   if($(window).width() < 768 ){
        $('.slider_logo .logo-list__wrapper').flickity({
          // options
          wrapAround: false,
          pageDots: false       
        }); 
   }

   

     

    setTimeout(function(){
      $('.video_slider').addClass('active');
    }, 2500);
    
    $('.slider_slick').flickity({
      // options
      wrapAround: true,
      pageDots: false       
    });

   
    
     $('.clhd_slider').flickity({
      // options
      wrapAround: true,
      pageDots: false,
      groupCells: false       
    }).addClass('active');
    
    $('.pdacd_heading .pdacd_heading_txt').on('click', function(e){
      e.preventDefault();
      show_prodcut_toggle($(this));  
      
    }).on('keydown', function(ev){
      if (ev.which ==13)  {
        show_prodcut_toggle($(this));
      }
    });
    
    function show_prodcut_toggle(that){
      if(that.hasClass('size_chart_sidebtn')){
         $('.side_chart').css('right', 0);
         $('.side_chart_bg').addClass('active');
      }else{
        //$('.pdacd_heading').removeClass('active');
        that.closest('.pdacd_heading').toggleClass('active');
        that.closest('.pdacd_heading').next('.pdacd_description').slideToggle();
      }
    }
    
    
    $('.pdacd_heading .pdacd_heading_sign').on('click', function(){
        sign_accoundin($(this));
    }).on('keydown', function(ev){
      if (ev.which ==13)  {
       // sign_accoundin($(this));
      }
    });
    function sign_accoundin(that){
        that.closest('.pdacd_heading').toggleClass('active');
        that.closest('.pdacd_heading').next('.pdacd_description').slideToggle();
    }
     
    
    $('.nav_sizeChart li').on('click', function(){
      $('.nav_sizeChart li').removeClass('active');
      $('.data_table_size').removeClass('active');   
      
      var val = $(this).data('id');
      
       $(this).addClass('active');
       $('.data_table_size[data-id="'+val+'"]').addClass('active');   
       
    });
    
    
    $('.size_btn_chart').on('click', function(){
      $('.side_chart').css('right', 0);
      $('.side_chart_bg').addClass('active');
      
    });
    
     $('.close_side, .side_chart_bg').on('click', function(){
        $('.side_chart').css('right', '-200vw');
        $('.side_chart_bg').removeClass('active');
     });
    
    
    $('.retch_nav li').on('click', function(){
      var value = $(this).data('id');
      
      $('html, body').animate({
        scrollTop: $('.retch_item[data-id="'+value+'"]').offset().top - 100
      }, 500);
    });
  
    setTimeout(function(){
      // addCollectionUrl();
    }, 2000);
    
    function addCollectionUrl(){
      $('.boost-pfs-filter-products .product__grid-item').each(function(){
        var url = $(this).find('a').attr('href');
        var title =  $(this).find('.product-thumbnail__title').html();
        $(this).find('.product-thumbnail').append('<a class="link_add" href="'+url+'">'+title+'</a>');
      });
      
    }
    
    /*
    $('body').on('keypress', ".boost-pfs-filter-button ", function(e){
       console.log(e.keyCode);
    	if(e.keyCode == 13){
            var enter_position = $(this).index();
             var add_class = $(this).closest('.boost-pfs-filter-option').find('.boost-pfs-filter-option-item-list .boost-pfs-filter-option-item').eq(0).find('.boost-pfs-filter-button');
            add_class.addClass('active');
           // add_class.focus();
          // $(this).focus();
            //$("#form input , select , textarea").eq(enter_position+1).focus();
         // foucs_fildter($(this));
        }
    });
    
      $('body').on('click', ".boost-pfs-filter-button ", function(e){
        foucs_fildter($(this));
      });
    
    function foucs_fildter(that){
      setTimeout(function(){
       that.blur().addClass('active');;
      }, 100);
    }
    
    */
    
  
    
  },
  size_map: function(){
    
             $('.unit-controls .unit-control').on('keydown', function(ev){
              
      if (ev.which ==13)  { 
          
          let ussizeconvert = true;
        if($('.size-chart h3').text().includes("Women's")){
          ussizeconvert = false;
        }
          
          if(!$(this).hasClass('selected')){
            var unit = $(this).attr('data-unit');

            //Handles Button State
            if(unit =='metric'){
              $('.unit-controls .imperial').removeClass('selected');
            }else{
              $('.unit-controls .metric').removeClass('selected');
            }
            $(this).addClass('selected');

            //Conversion Functions
              function cmToIn(cm){
                if(isNaN(cm)) {
                  return 'NA';
                }else{
                    return Math.round(cm*0.39370);
                }
              }
              function inToCm(inches){
               if(isNaN(inches)) {
                  return 'NA';
                }else{
                 return Math.round(inches/0.39370);
                }
              }
      

            function lbToKg(lb){
              if(isNaN(lb)) {
                  return 'NA';
                }else{
             	 return Math.round(10*(lb/2.2046))/10;
                }
            }

            function kgToLb(kg){
               if(isNaN(kg)) {
                  return 'NA';
                }else{
              		return Math.round(10*kg*2.2046)/10;
                }
            }

            var weightAttrArray = ['weight'];
            var blacklistAttrArray = ['size','dog size','examples of breed'];
            var lengthColumnPositions = [];
            var weightColumnsPositions = [];

            //Gets the column position of the column we need to convert the length and appends to the array
            $('.size-chart tr:first-child td').each(function(index){
              var currentAttribute = $(this).text().toLowerCase();
              if(weightAttrArray.indexOf(currentAttribute) == -1 && blacklistAttrArray.indexOf(currentAttribute) == -1){
                lengthColumnPositions.push(index+1);
              }
              if(weightAttrArray.indexOf(currentAttribute) > -1){
                weightColumnsPositions.push(index+1);
              }
            });

             
            //Goes through each column and converts each value except for the headings
            lengthColumnPositions.forEach(function(position){
              if(ussizeconvert){
                $('.size-chart tr:not(:first-child) td:nth-child('+position+')').each(function(){
                var currentUnitValue = $(this).text().toLowerCase();
                if(currentUnitValue.indexOf('-') > -1){
                  currentUnitValue = currentUnitValue.split('-');
                  currentUnitValue = currentUnitValue.map(function(value){
                    console.log(value, parseInt(value));
                    return parseInt(value);
                  });
                  if(unit =='metric'){
                    $(this).attr("inch", $(this).text().toLowerCase());
                    $(this).text(inToCm(currentUnitValue[0])+'-'+inToCm(currentUnitValue[1]));
                  } else {
                    // $(this).text(cmToIn(currentUnitValue[0])+'-'+cmToIn(currentUnitValue[1]));
                    $(this).text($(this).attr("inch"));
                  }
                } else {
                  currentUnitValue = parseInt(currentUnitValue);
                  if(unit =='metric'){
                    $(this).attr("inch", $(this).text().toLowerCase());
                    $(this).text(inToCm(currentUnitValue));
                  }else{
                    // $(this).text(cmToIn(currentUnitValue));
                    $(this).text($(this).attr("inch"));
                  }
                }
              });
              }else{
                if(unit=="metric"){
                   womenchartset(cmTable);
                    
                  }else{
                   womenchartset(cmTable);

                  }    
              }      
            });
            
           
            //If there is a second table we know it is the womens chart so we will manually target the general inseam column
            var tables = $('table');
            if(tables.length > 1){
              if(ussizeconvert){
                $('.size-chart table:last-child tr:not(:first-child) td:nth-child(2)').each(function(){
                var currentUnitValue = $(this).text();
                currentUnitValue = currentUnitValue.split('-');
                currentUnitValue = currentUnitValue.map(function(value){
                  return parseInt(value);
                });
                if(unit =='metric'){
                  $(this).text(inToCm(currentUnitValue[0])+'-'+inToCm(currentUnitValue[1]));
                }else{
                  $(this).text(cmToIn(currentUnitValue[0])+'-'+cmToIn(currentUnitValue[1]));
                }
              });
              }else{
                if(unit=="metric"){
                    womenchartset(cmTable);          
                  }else{
                    womenchartset(cmTable);   
                  } 
              }      
            }
            

            weightColumnsPositions.forEach(function(position){
              $('.size-chart tr:not(:first-child) td:nth-child('+position+')').each(function(){
                var currentUnitValue = $(this).text();
                if(currentUnitValue.indexOf('-') > -1){
                  currentUnitValue = currentUnitValue.split('-');
                  currentUnitValue = currentUnitValue.map(function(value){
                    return parseInt(value);
                  });
                  if(unit =='metric'){
                    $(this).text(lbToKg(currentUnitValue[0])+'-'+lbToKg(currentUnitValue[1]));
                  }else{
                    $(this).text(kgToLb(currentUnitValue[0])+'-'+kgToLb(currentUnitValue[1]));
                  }
                }else{
                  currentUnitValue = parseInt(currentUnitValue);
                  if(unit =='metric'){
                    $(this).text(lbToKg(currentUnitValue));
                  }else{
                    $(this).text(kgToLb(currentUnitValue));
                  }
                }
              });
            });
          }
      }
        });

        function womenchartset(tb){
             $('.section_chart table ').replaceWith(tb);
          }
          const cmTable='<table width="100%">'+
        '<tbody>'+
        '<tr>'+
        '<td>Size</td>'+
        '<td>US Size</td>'+
        '<td>Bust</td>'+
        '<td>Waist</td>'+
        '<td>Hips</td>'+
        '</tr>'+
        '<tr>'+
        '<td>XS</td>'+
        '<td><span>2</span></td>'+
        '<td>83 5/6</td>'+
        '<td>63 1/2</td>'+
        '<td>90 1/6</td>'+
        '</tr>'+
        '<tr>'+
        '<td>S</td>'+
        '<td>4-6</td>'+
        '<td>87 5/8</td>'+
        '<td>67 1/3</td>'+
        '<td>94 </td>'+
        '</tr>'+
        '<tr>'+
        '<td>M</td>'+
        '<td>8-10</td>'+
        '<td>95 1/4</td>'+
        '<td>75</td>'+
        '<td>101 3/5</td>'+
        '</tr>'+
        '<tr>'+
        '<td>L</td>'+
        '<td>12-14</td>'+
        '<td>102 7/8</td>'+
        '<td>82 5/9</td>'+
        '<td>109 2/9</td>'+
        '</tr>'+
        '<tr>'+
        '<td>XL</td>'+
        '<td>16-18</td>'+
        '<td>110 1/2</td>'+
        '<td>90 1/6</td>'+
        '<td>116 5/6</td>'+
        '</tr>'+
        '<tr>'+
        '<td>1X</td>'+
        '<td>16-18W</td>'+
        '<td>113</td>'+
        '<td>92 5/7</td>'+
        '<td>119 3/8</td>'+
        '</tr>'+
        '<tr>'+
        '<td>2X</td>'+
        '<td>20-22W</td>'+
        '<td>120 2/3</td>'+
        '<td>100 1/3</td>'+
        '<td>127</td>'+
        '</tr>'+
        '<tr>'+
        '<td>3X</td>'+
        '<td>24-26W</td>'+
        '<td>128 1/4</td>'+
        '<td>108</td>'+
        '<td>134 5/8</td>'+
        '</tr>'+
        '</tbody>'+
        '</table>';
  },
  
  new_size_map: function(){
    
        $('.unit-controls .unit-control').click(function(){
          
          let ussizeconvert = true;
        if($('.size-chart h3').text().includes("Women's")){
          ussizeconvert = false;
        }
          
          if(!$(this).hasClass('selected')){
            var unit = $(this).attr('data-unit');

            //Handles Button State
            if(unit =='metric'){
              $('.unit-controls .imperial').removeClass('selected');
            }else{
              $('.unit-controls .metric').removeClass('selected');
            }
            $(this).addClass('selected');

            //Conversion Functions
              function cmToIn(cm){
                if(isNaN(cm)) {
                  return 'NA';
                }else{
                    return Math.round(cm*0.39370);
                }
              }
              function inToCm(inches){
               if(isNaN(inches)) {
                  return 'NA';
                }else{
                 return Math.round(inches/0.39370);
                }
              }
      

            function lbToKg(lb){
              if(isNaN(lb)) {
                  return 'NA';
                }else{
             	 return Math.round(10*(lb/2.2046))/10;
                }
            }

            function kgToLb(kg){
               if(isNaN(kg)) {
                  return 'NA';
                }else{
              		return Math.round(10*kg*2.2046)/10;
                }
            }

            var weightAttrArray = ['weight'];
            var blacklistAttrArray = ['size','dog size','examples of breed'];
            var lengthColumnPositions = [];
            var weightColumnsPositions = [];

            //Gets the column position of the column we need to convert the length and appends to the array
            $('.size-chart tr:first-child td').each(function(index){
              var currentAttribute = $(this).text().toLowerCase();
              if(weightAttrArray.indexOf(currentAttribute) == -1 && blacklistAttrArray.indexOf(currentAttribute) == -1){
                lengthColumnPositions.push(index+1);
              }
              if(weightAttrArray.indexOf(currentAttribute) > -1){
                weightColumnsPositions.push(index+1);
              }
            });

             
            //Goes through each column and converts each value except for the headings
            lengthColumnPositions.forEach(function(position){
              if(ussizeconvert){
                $('.size-chart tr:not(:first-child) td:nth-child('+position+')').each(function(){
                var currentUnitValue = $(this).text().toLowerCase();
                if(currentUnitValue.indexOf('-') > -1){
                  currentUnitValue = currentUnitValue.split('-');
                  currentUnitValue = currentUnitValue.map(function(value){
                    console.log(value, parseInt(value));
                    return parseInt(value);
                  });
                  if(unit =='metric'){
                    $(this).attr("inch", $(this).text().toLowerCase());
                    $(this).text(inToCm(currentUnitValue[0])+'-'+inToCm(currentUnitValue[1]));
                  } else {
                    // $(this).text(cmToIn(currentUnitValue[0])+'-'+cmToIn(currentUnitValue[1]));
                    $(this).text($(this).attr("inch"));
                  }
                } else {
                  currentUnitValue = parseInt(currentUnitValue);
                  if(unit =='metric'){
                    $(this).attr("inch", $(this).text().toLowerCase());
                    $(this).text(inToCm(currentUnitValue));
                  }else{
                    // $(this).text(cmToIn(currentUnitValue));
                    $(this).text($(this).attr("inch"));
                  }
                }
              });
              }else{
                if(unit=="metric"){
                   womenchartset(cmTable);
                    
                  }else{
                    var size = $.parseJSON($('#sizechartonPage').html());

                    womenchartset(size);

                  }    
              }      
            });
            
           
            //If there is a second table we know it is the womens chart so we will manually target the general inseam column
            var tables = $('table');
            if(tables.length > 1){
              if(ussizeconvert){
                $('.size-chart table:last-child tr:not(:first-child) td:nth-child(2)').each(function(){
                var currentUnitValue = $(this).text();
                currentUnitValue = currentUnitValue.split('-');
                currentUnitValue = currentUnitValue.map(function(value){
                  return parseInt(value);
                });
                if(unit =='metric'){
                  $(this).text(inToCm(currentUnitValue[0])+'-'+inToCm(currentUnitValue[1]));
                }else{
                  $(this).text(cmToIn(currentUnitValue[0])+'-'+cmToIn(currentUnitValue[1]));
                }
              });
              }else{
                if(unit=="metric"){
                    womenchartset(cmTable);          
                  }else{
                    var size = $.parseJSON($('#sizechartonPage').html());
                    womenchartset(size);
                  } 
              }      
            }
            

            weightColumnsPositions.forEach(function(position){
              $('.size-chart tr:not(:first-child) td:nth-child('+position+')').each(function(){
                var currentUnitValue = $(this).text();
                if(currentUnitValue.indexOf('-') > -1){
                  currentUnitValue = currentUnitValue.split('-');
                  currentUnitValue = currentUnitValue.map(function(value){
                    return parseInt(value);
                  });
                  if(unit =='metric'){
                    $(this).text(lbToKg(currentUnitValue[0])+'-'+lbToKg(currentUnitValue[1]));
                  }else{
                    $(this).text(kgToLb(currentUnitValue[0])+'-'+kgToLb(currentUnitValue[1]));
                  }
                }else{
                  currentUnitValue = parseInt(currentUnitValue);
                  if(unit =='metric'){
                    $(this).text(lbToKg(currentUnitValue));
                  }else{
                    $(this).text(kgToLb(currentUnitValue));
                  }
                }
              });
            });
          }
        });

        function womenchartset(tb){
             $('.section_chart table ').replaceWith(tb);
          }
          const cmTable='<table width="100%">'+
        '<tbody>'+
        '<tr>'+
        '<td>Size</td>'+
        '<td>US Size</td>'+
        '<td>Bust</td>'+
        '<td>Waist</td>'+
        '<td>Hips</td>'+
        '</tr>'+
        '<tr>'+
        '<td>XS</td>'+
        '<td><span>2</span></td>'+
        '<td>83 5/6</td>'+
        '<td>63 1/2</td>'+
        '<td>90 1/6</td>'+
        '</tr>'+
        '<tr>'+
        '<td>S</td>'+
        '<td>4-6</td>'+
        '<td>87 5/8</td>'+
        '<td>67 1/3</td>'+
        '<td>94 </td>'+
        '</tr>'+
        '<tr>'+
        '<td>M</td>'+
        '<td>8-10</td>'+
        '<td>95 1/4</td>'+
        '<td>75</td>'+
        '<td>101 3/5</td>'+
        '</tr>'+
        '<tr>'+
        '<td>L</td>'+
        '<td>12-14</td>'+
        '<td>102 7/8</td>'+
        '<td>82 5/9</td>'+
        '<td>109 2/9</td>'+
        '</tr>'+
        '<tr>'+
        '<td>XL</td>'+
        '<td>16-18</td>'+
        '<td>110 1/2</td>'+
        '<td>90 1/6</td>'+
        '<td>116 5/6</td>'+
        '</tr>'+
        '<tr>'+
        '<td>1X</td>'+
        '<td>16-18W</td>'+
        '<td>113</td>'+
        '<td>92 5/7</td>'+
        '<td>119 3/8</td>'+
        '</tr>'+
        '<tr>'+
        '<td>2X</td>'+
        '<td>20-22W</td>'+
        '<td>120 2/3</td>'+
        '<td>100 1/3</td>'+
        '<td>127</td>'+
        '</tr>'+
        '<tr>'+
        '<td>3X</td>'+
        '<td>24-26W</td>'+
        '<td>128 1/4</td>'+
        '<td>108</td>'+
        '<td>134 5/8</td>'+
        '</tr>'+
        '</tbody>'+
        '</table>';
  },
  product_option: function(){

     
    setTimeout(function(){
      var lenght = $('.feefowidget-global__reviews-container feefowidget-feedbacks-item').length;
      if(lenght > 5){
        $('.feefowidget-global__reviews-container').append('<div class="feefo_more_btn"> View More</div>');  
      }
    }, 5800);

    $('body').on('click', '.feefo_more_btn', function(){
      $('feefowidget-feedbacks-item').show();
    });
     
    
    
     $('body').on('click', '.quick-shop__lightbox .button--add-to-cart', function(){
      
      setTimeout(function(){
     	 $.fancybox.close();
         $('.header-cart').addClass('show-mini-cart');
      }, 1200);
    });    

    
    $('body').on('click', '.swatch__option', function(){
      var sw_img = $(this).data('url');
      
      if( $('.product_scroll[data-url="'+sw_img+'"]').length > 0){
         var top = $('.product_scroll[data-url="'+sw_img+'"]').offset().top; 
      } 
       change_buy_it();
      
    });
    $('body').on('keydown', '.swatch__option', function(ev){
      if (ev.which ==13)  { 
         $(this).find('input').trigger("click");
         change_buy_it();
      }
    });
    
     
    
    
    function change_buy_it(){
      setTimeout(function(){ 
          var id = $('body.product [name="id"]').val();
          var url = $('.direct_url').data('href');
         url = url+id+':1';
          $('.direct_url').attr('href', url);
 
            // slider 
             var id = $('.variant-selection__variants option:selected').attr("data-meida");
             var index = $('.product-gallery_item[data-id="'+id+'"]').data('index'); 
             $('.thumb_slider_show').flickity('select', index); 
        
      }, 60);
    }
     
     
    
   
        // option list
    $('body').on('click', '.option_value', function(){ 
      	 option_list($(this));
    }).on('keydown', '.option_value', function(ev){
      if (ev.which ==13) {
          option_list($(this));
      }
    });
    
    
    function option_list(that){
        var val = that.data('val');
      	var index = that.closest('.option_list').data('index');
        that.closest('.option_list').find('.option_value').removeClass('selected');
      	that.addClass('selected');
      	$('.swatch__options[data-variant-option-index="'+index+'"] .swatch-element[data-value="'+val+'"] label').trigger('click').addClass('active');      	
    }
    
    setTimeout(function(){
    	sold_out_function();
    }, 400);
    
    function sold_out_function(){
      var size = $('.product__form_option').data('size');
      
      for(var i = 0; size > i; i +=1){
        var ind = 0;
        $('.swatch__options[data-variant-option-index="'+i+'"] .swatch__option').each(function(){
            
            var soild = $(this).find('[type="radio"]').data('variant-option-available'); 
            if(soild == false){ 
              var sold_label = $('.option_list[data-index="'+i+'"] .option_value:eq('+ind+')').attr('aria-label');
              sold_label +='Sold Out';
              $('.option_list[data-index="'+i+'"] .option_value:eq('+ind+')').addClass('sold_outs').attr('aria-label', sold_label);
            }
          	ind +=1;
          
        });
        
      }
      
    }
      
    
  },
  error_remove: function(){
    // action-area__link
    $('.action-area__link').on('click', function(){
      $('.onclick_hide_value').val('');
    });
    
  },
  update_cart: function(){
    
    $('.qty_inverse').on('click', function(){
      update_cart_value($(this));
    }).on('keydown', function(ev){
        // ev.preventDefault();
      if (ev.which ==13)  {
          update_cart_value($(this));
      }
    });
    
    $('.cart_quantity').on('change', function(){
      var qty = $(this).val();
       var id = $(this).data('id');
       console.log(qty);
       console.log(id);
      
       change_qty(qty, id);
    }).on('keydown', function(ev){
        // ev.preventDefault();
      if (ev.which ==13)  {
        var qty = $(this).val();
        var id = $(this).data('id');
           change_qty(qty, id);
      }
    });
    
    
    function update_cart_value(that){
       var value_box = that.closest('.cart_item_flx').find('[name="quantity"]');
        var qty = parseInt(value_box.val());
        if(that.hasClass('qty_plus')){
          qty +=1;
        }else{
          qty -=1;
        }
      var id = value_box.data('id');
      change_qty(qty, id);
    }
    
    function change_qty(qty, id){ 
       jQuery.post('/cart/change.js', 
                   { quantity: qty, id: id }).done(function() { 
         			window.location.href = '/cart';
                
              });
    }
     
    
  },
  gift_cart: function(){
    // remove all attr
    
    $('.remove_attr').on('click', function(){
       $.ajax({
          type: "GET",
          url: '/cart.js',
          dataType: 'json',
          success: function(resp) { 
              var nullHash = {};
              for ([key, value] of Object.entries(resp.attributes)) {    
                  nullHash[key] = 'note';
              }
              $.ajax({
                  type: "POST",
                  url: '/cart/update.js',
                  data: {attributes:nullHash},
                  dataType: 'json'
              });
          }
      });
    });
    
    
    
    var GIFTWRAP_PRODUCT_TYPE = 'Gift Box';
  	var GIFTWRAP_VARIANT_ID = 7259307802652; //39325627547744;
    
    
    // mincart;
      $('body').on('click', '.js-giftwrap', function(){ 
         var gift_val = $(this).data('val');
       if ($(this).is(':checked') == true) {
           $(this).closest('.giftwrap-option').addClass('active');
             $(this).closest('.giftwrap-option').next('.gift-note-field').show();
             var val =  $(this).closest('.giftwrap-option').next('.gift-note-field').find('textarea').data('val');
        	 $(this).closest('.giftwrap-option').next('.gift-note-field').find('textarea').attr('name', 'attributes['+val+']').val('note');
         
         get_cart(1, gift_val);
       }else{
         $(this).closest('.giftwrap-option').removeClass('active');
         $(this).closest('.giftwrap-option').next('.gift-note-field').hide();
          $(this).closest('.giftwrap-option').next('.gift-note-field').find('textarea').removeAttr('name');
         get_cart(0, gift_val);
       }
    });
    
    // cart
    
     $('.giftwrap_btn').on('click', function(ev){
      ev.preventDefault();
       tab_gift($(this));
    }).on('keydown', function(ev){
        // ev.preventDefault();
      if (ev.which ==13)  {
          tab_gift($(this));
      }
    });
    
    function tab_gift(that){
      var gift_val = that.data('val');
      var gift_qty = that.data('qty');
      
      that.toggleClass('active');
      if (that.hasClass('active')) { 
             that.closest('.giftwrap-option').next('.gift-note-field').show();
             var val = that.closest('.giftwrap-option').next('.gift-note-field').find('textarea').data('val');
        	 that.closest('.giftwrap-option').next('.gift-note-field').find('textarea').attr('name', 'attributes['+val+']').val('note');
        	 get_cart(1, gift_val, gift_qty);
           
       }else{
         that.closest('.giftwrap-option').next('.gift-note-field').hide();
         that.closest('.giftwrap-option').next('.gift-note-field').find('textarea').removeAttr('name');
         get_cart(0, gift_val, gift_qty);
       }
    }
    
    
    // remove cart item
    $('.cart__remove-btn').on('click', function(){
      var gift_val = $(this).closest('.cart__card').find('.cart__info').find('.giftwrap_btn.active').data('val');
      
      if(typeof gift_val !== undefined)
       get_cart(0, gift_val, 1);
    });
    
    // remove min cart item
    $('body').on('click', '.ajax-cart__delete', function(){
      var gift_val = $(this).closest('.ajax-cart__product').find('.giftwrap-option.active').find('.js-giftwrap').data('val');
      console.log(gift_val);
      
      if(typeof gift_val !== undefined)
      get_cart(0, gift_val, 1);
    });
    
    
    function add_gift(cart, gift_val, gift_qty){ 
      var check_gift = true;
      $.each(cart.items, function(index, item){
        if(item.id == GIFTWRAP_VARIANT_ID){
           check_gift = false;
        } 
      });
       
      
      if(check_gift){}
        var data = 'id='+ GIFTWRAP_VARIANT_ID + '&quantity=1'
	    $.ajax({
	      type: 'POST',
          url: '/cart/add.js',
	      dataType: 'json',
	      data: data,
	      success: function(res){
            /*
	          if(typeof gift_val !== undefined){
                console.log(gift_val);
                $.ajax({
                type: 'POST',
                url: '/cart/update.js',
                  data: 'attributes['+gift_val+': null]'
              });
            } 
            */
	      },
          error: function(error){
            console.log(error);
          } 
        }); 
      
      
    
      
    }
    
    function remove_gift(cart, gift_val, gift_qty){
      var qty = 0;
      $.each(cart.items, function(index, item){
        if(item.id == GIFTWRAP_VARIANT_ID){
          qty = item.quantity - 1; 
        } 
      });
     
      // remove gift
        $.ajax({
          type: "POST",
          url: "/cart/change.js",
          dataType: "json",
          data: {
            id: GIFTWRAP_VARIANT_ID,
            quantity: qty,
          },
	      success: function(res){
	        console.log(res);
	      },
          error: function(error){
            console.log(error);
          }          
        });
      
      setTimeout(function(){
        // remove attr
        if(typeof gift_val !== undefined){
            $.ajax({
            type: 'POST',
            url: '/cart/update.js',
            data: 'attributes['+gift_val+']='
          });
        } 
      },400);
    }
    
    
    
    function get_cart(value, gift_val, gift_qty){ 
      $.ajax({
        dataType: "json", 
        url: "/cart.js",
        success: function (cart) {
          if(value){
            add_gift(cart, gift_val, gift_qty);
          }else{
            remove_gift(cart, gift_val, gift_qty);
          }
        }
      }); 
    }
    
    
  },
  tab_app: function(){
    
    $('.cart__remove-btn').on('keydown', function(ev){
      if(ev.which ==13)  {
        var url = $('.cart__remove-btn').attr('href');
        window.location.href = url;
      }
    });
    
    
    $('form#cart_form [type="submit"]').on('keydown', function(ev){
      if (ev.which ==13)  {
       window.location.href = '/checkout';
      }
    });
    
    $('.quick-shop__buttons').on('click', function(){
       setTimeout(function(){ 
         console.log('gaurav');
          $('.product_name').attr('tabindex', 0);
         bedhad.product_slider();
         // $('.quick_shop').attr({'tabindex': '0', 'aria-label': 'quick view is open'});
       }, 2000);
    });
    
    setTimeout(function(){ 
     // $('.quick_shop').attr('aria-label', 'quick view is open');
    }, 600);
    
     setTimeout(function(){ 
       tab_txt(); 
       
       $('.boost-pfs-filter-option-range-amount-min, .boost-pfs-filter-option-range-amount-max').attr('tabindex', '0');
       
       var min = $('.boost-pfs-filter-option-range-amount-min').val();
       var max = $('.boost-pfs-filter-option-range-amount-max').val();
       $('.boost-pfs-filter-option-range-amount-split').prepend('<div class="hide_label_filter" tabindex="0" aria-label="input field minimum value '+min+' dollars">'+min+'</div>')
       													.append('<div class="hide_label_filter" tabindex="0" aria-label="input field maximum value '+max+' dollars">'+max+'</div>');
       
        //$('.boost-pfs-filter-option-range-amount-min, .boost-pfs-filter-option-range-amount-max').attr('tabindex','-1');
       
       
       // size  
        $('.boost-pfs-filter-option-size .boost-pfs-filter-option-item-list .boost-pfs-filter-option-item').each(function(){
          var txt = $(this).find('.boost-pfs-filter-option-value').html(); 
          $(this).find('button.boost-pfs-filter-button').attr('aria-label', 'size '+txt);
        });
         
       
       // cart page
       $('.shopify-cleanslate ul li:eq(2) iframe').attr('tabindex', '-1');
       $('.shopify-cleanslate ul li:eq(2)').prepend('<div class="Paypal_aria" aria-label="Paypal" tabindex="0">Paypal</div>');
      
     }, 5000);
    
    function tab_txt(){  
      $('.starapps-accordion .starapps-panel').each(function(){
        var li_heading = $(this).find('.starapps-title').html();
        $(this).find('.starapps-title').html('');
         
        $(this).prepend('<div class="panel_heading" tabindex="0">'+li_heading+'</div>');
        
        var heade_txt = $(this).find('.starapps-body').text().trim();
        $(this).append('<div class="starapps-body hide_txt" tabindex="0">'+heade_txt+'</div>');
      }); 
      
      $('.panel_heading .pull-right').attr('aria-label', 'drop down icon');
    }
    
    $('body').on('click', '.panel_heading', function(){
      $(this).toggleClass('active');
      $(this).closest('.starapps-panel').find('.starapps-body').toggleClass('active');
    });
    
    $('.jsRecommendedProducts, .jsProduct').attr('tabindex', '0');
    
  },
  speed: function(){
    
    setTimeout(function(){
      var video_url = $('.index_video').data('id'); 
      
      if(typeof video_url !== undefined ){
       var html = '<video class="video_box" autoplay loop muted playsinline preload="none">'+
                        '<source src="'+video_url+'" type="video/mp4" />'+
                   '</video>';
         $('.index_video').append(html);
      }
      
      var video_u = $('.index_video_left_right').data('id'); 
        if(typeof video_u !== undefined ){
       var html = '<video autoplay loop muted playsinline preload="none">'+
                        '<source src="'+video_u+'" type="video/mp4" />'+
                   '</video>';
         $('.index_video_left_right').append(html);
      }
      
       
    }, 8000);
    
    
  },
  collection_product_url: function(){
    
    console.log(product_detail);
    setTimeout(function(){
      if(typeof product_detail !== 'undefined'){
        $('.collection__content .boost-pfs-filter-products .product__thumbnail').each(function(){
          	var id = $(this).data('id');
          	var that = $(this);
          
          $(product_detail).each(function(index, item){
            if(item.id == id){
              that.find('a').attr('href', item.url);
              that.find('.product-thumbnail__price, .quick_shop, .sale-sticker').hide();
            }            
          });
          
        });
        
      }
    
    },4800);
    
  },
  mincart: function(){

    $('body').on('click', '.js-im-add-cart', function(){
      setTimeout(function(){
          get_cart();
      }, 2500);
    });
   

    $('.mmc_shopping_link a').on('click', function(){
      var url = $(this).attr('href');
      window.location.href= url;
    });
    
    $('.cart__remove').on('click', function(){
      console.log('remove');
      setTimeout(function(){
        location.reload();
      }, 500); 
    });
    
    $('.header-cart a, .header-cart__icon').on('click', function(e){
      e.preventDefault();
      $('.min_cart, body').addClass('active');
    });
    $('.min_bg, .min_close').on('click', function(){
       $('.min_cart, body').removeClass('active');
    });
    
    $('body').on('click', '.remove_item', function(e){
       e.preventDefault();
      var line = $(this).data('line');
      update_line(line, 0);
      // $(this).closest('.mmc_items').hide();
    });
    
    $('body').on('click', '.mmc_sign', function(){
      var qty = parseInt($(this).closest('.mmc_qty').find('.quantity-input').val());
      var line = $(this).closest('.mmc_qty').data('line-item-key');
      var id = $(this).closest('.mmc_qty').find('.quantity-input').data('id');
      if($(this).hasClass('mmc_min')){
        qty = qty - 1;
      }else{
        qty = qty + 1;
      }
      
       update_qty(qty, id)
       
       // update_line(line, qty);
      
    });
    
    $('body').on('change', '.quantity-input', function(){
       var qty = parseInt($(this).val());
       var line = $(this).data('line-id');
       var id = $(this).data('id');
      
       //update_line(line, qty);
      update_qty(qty, id)
    });
    
    
    $('body').on('submit','form[action="/cart/add"]', function(e){
       e.preventDefault();
      addItem($(this));
    });
    
    function addItem(that) {
       $.ajax({
          type: 'POST', 
          url: '/cart/add.js',
          dataType: 'json', 
          data: that.serialize(),
           success: function(cart) {
             get_cart();  
           },
           error: function(response) {
             //alert(response);
           }
       });
    }
    
    
    function update_line(line, qty){
      var url = '/cart/change?line='+line+'&quantity='+qty;
      
           $.ajax({
                    type: 'POST',
                    url: url,
                    dataType: 'json',
                    success: function(cart) {
                       get_cart();  
                    },
                    error: function(response) {
                         location.reload();
                    }
                }); 
    }
    
    function update_qty(qty, id){
       $.ajax({
          type: "POST" ,
          url: "/cart/change.js",
          dataType: "json",
          data: {
            id: id,
            quantity: qty,
          },
          success: function(resp) { 
            	//location.reload();
                get_cart();
          }
      });
    }
    
    
    function get_cart(){
      
      /*
        $.ajax({ 
          url:'/cart', 
          success: function(cart) { 
            var html = $(cart).find('.min_cart_inner').html();
             
            $('.min_cart_inner').html(html);
            $('.min_cart').addClass('active');
          }
       });
       */
      
      
      jQuery.getJSON('/cart.js', function(cart) {
         console.log(cart);
         var html = '', count = 0;
         console.log(cart.items.length);
        
         if (cart.items.length == 0){
           $('.mmc_item_box').html('<p class="empty_cart">Empty Cart</p>');
            $('.mmc_total_price').html(Shopify.formatMoney(cart.total_price));
         }
          for(var i=0; i<cart.items.length; i++){
            
            var item = cart.items[i];
           
            var forloop = i + 1; 
            
            if(item.product_title != 'Gift Box'){
              count += item.quantity; 
             html += '<div class="mmc_items">'+
                      '<div class="mmc_img">'+
                         '<a href="'+item.url+'" class="cart_page_image">'+
                            '<img src="'+item.image+'"/>'+
                          '</a>'+
                      '</div>'+
            '<div class="mmc_detail">'+
              '<div class="mmc_title"><a href="'+ item.url+'">'+item.title+'</a> </div>'+
               
              '<div class="mmc_price" tabindex="0">'+Shopify.formatMoney(item.line_price)+' </div>'+
              
               '<div class="mmc_qty" data-line-item-key='+forloop+'>'+
                 '<div aria-label="Cart quantity minus" class="mmc_sign mmc_min"><span class="icon "><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><g id="minus"><rect x="5" y="46" width="90" height="8"/></g></svg></span></div>'+
                  '<input class="quantity-input" data-id="'+item.id+'"  type="text" name="quantity" value="'+item.quantity +'" data-line-id="'+ forloop +'">'+
                 '<div aria-label="Cart quantity plus" class="mmc_sign mmc_plus"><spna class="icon "><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><g id="plus"><polygon points="95 46 54 46 54 5 46 5 46 46 5 46 5 54 46 54 46 95 54 95 54 54 95 54 95 46"/></g></svg></span></div>'+
               '</div> '; 
              
                               	 
               
            html += '</div>'+
            
            '<div class="mmc_close" >'+
               '<button class="close remove_item" tabindex="0" aria-label="Remove item" data-line="'+ forloop +'"><span class="icon "><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><g id="x"><polygon points="97.83 7.83 92.17 2.17 50 44.34 7.83 2.17 2.17 7.83 44.34 50 2.17 92.17 7.83 97.83 50 55.66 92.17 97.83 97.83 92.17 55.66 50 97.83 7.83"/></g></svg></span></button>'+
            '</div>'+
            
          '</div>';
            }
            
            $('.mmc_item_box').html(html);
            $('.mmc_total_price').html(Shopify.formatMoney(cart.total_price));
            
            $('.min_cart, body').addClass('active');
            $('.header-cart__count').html(count).show();
             
          }
       });
      
    }
    
  },
  collection_hover: function(){
      $('.hover_event').on('mouseover', function(){
           var id = $(this).data('id'); 
           $(this).closest('.product-item--images').find('.product-item--image').removeClass('hov');
           $(this).closest('.product-item--images').find('.product-item--image[data-id="'+id+'"]').addClass('hov');
      });
  },
  addon_all: function(){
    var height = $('.product-gallery__main .product-gallery__image:first-child').height() + 320;
    if(typeof height !== 'undefined'){
      $('.product-gallery').css('height', height);
    }

    $('body').on('change', '.swatch__option', function(){
       var img_id = $('.variant-selection__variants[name="id"] option:selected').attr('data-meida');
       var qty = $('.variant-selection__variants[name="id"] option:selected').attr('data-qty');
       var tg_div = $('.product-gallery__main .product-gallery__image[data-media="'+img_id+'"]').html();
       

       if (window.PXUTheme.theme_settings.display_inventory_left) {
          let itemsLeftText = window.PXUTheme.translation.product_count_other;
       
        if (qty == '1' || qty == '0') {
          itemsLeftText = window.PXUTheme.translation.product_count_one;
        }
        var show_value = 10; 
         if(show_value >= qty){
           $('.items_left').html(qty + ' '+itemsLeftText);
         }else{
           $('.items_left').html('');
         }
         
      }
      

     /*
      if(typeof img_id !== 'undefined' && typeof tg_div !== 'undefined' && tg_div.length > 0 && $(this).closest('form').hasClass('main_product_form') ){
        $('.product-gallery__main .product-gallery__image').show();
         $('.product-gallery__main .product-gallery__image[data-media="'+img_id+'"]').hide();
        $('product-gallery__image .first_img').hide();
        $('.product-gallery__main').prepend('<div class="product-gallery__image first_img">'+tg_div+'</div>');
      }
      
      
      if(tg_div.length > 0 ){
         var top = tg_div.offset().top - $('.product-gallery__main').offset().top - 20; 
        $('.product-gallery').animate({
          scrollTop: top
        }, 700);
      }
      */
        
    });
    
  },
  zoom_img: function(){
     
    if($(window).width() > 768){
       $('.zoom').zoom();
      
    }     
  },
  menu_funciton: function(){
    $('.close-dropdown').on('click', function(){
      $(this).closest('.has-submenu').find('.mobile-submenu__list').slideToggle();
    }); 
  },
  ada_option: function(){
  
    $('.page__content h2, .page__content h3, .page__content h4, .page__content h5, .page__content li, .page__content p, .page__content img').attr('tabindex', '0'); 

    $('.product-template').removeAttr('tabindex');
    setTimeout(function(){
      $('select.sort_by, .product-thumbnail__title, .feefowidget-product-stars__reviews-count, .feefowidget-header-information-title, .feefowidget-rating-values, .feefowidget-feedbacks-item feefowidget-tag').attr('tabindex', '0');  
    }, 7500);
      
  }
}




setTimeout(function() {	
  
  bedhad.slider_funciton();
  bedhad.new_size_map();
   
  bedhad.product_option();
   
  bedhad.error_remove();  
  bedhad.update_cart(); 
  
  
  bedhad.tab_app();
  bedhad.mincart();    
  bedhad.collection_hover();
  bedhad.addon_all();
  bedhad.zoom_img();
 
  bedhad.ada_option();

  bedhad.product_slider();
 
 // bedhad.menu_funciton(); 
  // bedhad.gift_cart();
});

$(window).scroll(function(){
  var top = $(window).scrollTop();
  if(top > 100){
    $('#header').addClass('active_subhead');
  }else{
    $('#header').removeClass('active_subhead');
  }  
  
});



 


